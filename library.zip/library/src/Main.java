import java.util.*;


public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        BookShelf bookShelf = BookShelf.getInstance();

        String choice = "";

        System.out.println("Welcome to library!");
        System.out.println("----------------------------------------------------");
        System.out.println("Please type 'add' if you want to add books");
        System.out.println("please type 'remove' if you want to remove books");
        System.out.println("please type 'view' if you want to view the collection of books");
        while (true) {
            System.out.println("Please type your input: ");

            choice = input.nextLine();


            if (choice.equalsIgnoreCase("add") || choice.equalsIgnoreCase("remove") || choice.equalsIgnoreCase("view")) {

                int ID = 0;
                String bookName;

                switch (choice) {
                    case "add":
                        System.out.println("Enter the Name of the book: ");
                        bookName = input.nextLine();
                        System.out.println("Enter the ID of the book: ");
                        ID = input.nextInt();
                        bookShelf.addBook(ID, bookName);
                        System.out.println("The book: " + bookName + " with an ID of " + ID + " is Successfully added");
                        bookShelf.viewBook();
                        break;

                    case "remove":
                        System.out.println("please enter the ID you want to remove: ");
                        ID = input.nextInt();
                        bookShelf.removeBook(ID);
                        System.out.println("Book Successfully removed");
                        bookShelf.viewBook();
                        break;

                    case "view":

                        System.out.println("List of books");
                        System.out.println("-----------------------------");
                        bookShelf.viewBook();
                        break;


                }
            } else {
                System.out.println("Invalid input");
            }
        }




    }
}