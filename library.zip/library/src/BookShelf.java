
import java.util.*;

public class BookShelf {

    private BookShelf() {

    }

    private static BookShelf instance;

    public static BookShelf getInstance(){
        if(instance == null){
            instance = new BookShelf();
        }
        return instance;
    }

    private Map<Integer,String> books = new HashMap<>();

    public void addBook(int bookID, String book){
        books.put(bookID,book);
    }

    public void removeBook(int bookID){
        books.remove(bookID);
    }

    public void viewBook(){
        for (Map.Entry<Integer, String> bookCollection: books.entrySet()){
            System.out.println(bookCollection.getKey() + "-->" +bookCollection.getValue());
        }
    }


}
